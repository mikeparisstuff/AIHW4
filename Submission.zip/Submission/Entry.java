public class Entry {
    public int y;
    public int[] x;

    public Entry(int y, int[] x) {
        this.y = y;
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public int[] getX() {
        return x;
    }
}